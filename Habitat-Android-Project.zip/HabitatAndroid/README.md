# Habitat Android — Core Shell v0.1.0

This is a real Android Studio project for the first Habitat app shell.

## Current capabilities
- Native Android launcher app
- Local chat-style interface
- No sensitive Android permissions requested
- Explicit human-authority status
- Local session display

## Deliberately not included yet
- AI/API credentials
- camera/microphone/location permissions
- accessibility service
- background network services
- financial actions
- credential storage

Those are separate security-reviewed modules to be added deliberately.

## Build
Open this project in Android Studio and build the `app` module. Android SDK 35 and JDK 17 are expected.
