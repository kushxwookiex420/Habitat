package com.habitat.core

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var log: TextView
    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,32,32,24); setBackgroundColor(Color.rgb(9,10,15)) }
        val title = TextView(this).apply { text="HABITAT"; textSize=30f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(0,12,0,6) }
        status = TextView(this).apply { text="● BRAIN SHELL ONLINE"; textSize=15f; setTextColor(Color.rgb(100,220,150)); gravity=Gravity.CENTER; setPadding(0,0,0,24) }
        val input = EditText(this).apply { hint="Talk to Habitat..."; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(false); setBackgroundColor(Color.rgb(25,27,35)); setPadding(20,18,20,18) }
        val send = Button(this).apply { text="SEND" }
        log = TextView(this).apply { text="Ready. Human authority: ACTIVE\n"; textSize=14f; setTextColor(Color.LTGRAY); setPadding(0,24,0,0) }
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row.addView(input, LinearLayout.LayoutParams(0,120,1f)); row.addView(send, LinearLayout.LayoutParams(130,120))
        root.addView(title); root.addView(status); root.addView(row); root.addView(log)
        setContentView(root)
        send.setOnClickListener { val msg=input.text.toString().trim(); if(msg.isNotEmpty()){ log.text="${log.text}\n[$now()] YOU: $msg\nHabitat: Received. Brain adapter not connected yet."; input.text.clear() } }
    }
}
