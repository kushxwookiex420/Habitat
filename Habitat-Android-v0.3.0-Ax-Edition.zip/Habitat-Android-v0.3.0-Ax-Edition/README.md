# Habitat v0.3.0 — Ax Edition

Habitat is the Android command center for Ax. Ax remains the manager/orchestrator; external AI services are hired workers.

## Included
- Futuristic animated Ax hologram shell.
- Ax command console.
- Persistent local task board with QUEUED / WORKING / COMPLETE / ERROR states.
- Worker roster and local provider configuration.
- Provider adapters for OpenAI-compatible endpoints, Anthropic Messages, and Gemini generateContent.
- Muse is represented as a configurable custom/compatible worker; no unsupported private Muse API is assumed.
- Android home-screen widget.
- GitHub Actions debug APK workflow.
- No API keys are hard-coded.

## Worker flow
User → Ax → WorkerAdapter → selected worker → report → Ax → User.

External provider access requires the provider's own endpoint/model/key and is subject to that provider's current API access and terms.
