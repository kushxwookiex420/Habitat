package com.habitat.core

data class HabitatTask(val id: Long, val title: String, val status: String, val worker: String, val result: String = "")
data class Worker(val id: String, val name: String, val kind: String, val endpoint: String = "", val model: String = "", val enabled: Boolean = false)
