package com.habitat.core

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.sin

class HologramView(context: Context): View(context) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG); private var phase=0f
    init { setLayerType(View.LAYER_TYPE_SOFTWARE,null) }
    override fun onDraw(c:Canvas){ super.onDraw(c); val w=width.toFloat();val h=height.toFloat(); c.drawColor(Color.rgb(8,12,20)); p.style=Paint.Style.STROKE;p.strokeWidth=2f;p.color=Color.rgb(60,190,255);p.setShadowLayer(12f,0f,0f,Color.rgb(60,190,255)); val cx=w/2; val cy=h*.48f; c.drawOval(cx-w*.28f,cy-h*.31f,cx+w*.28f,cy+h*.31f,p);c.drawOval(cx-w*.20f,cy-h*.25f,cx+w*.20f,cy+h*.25f,p);p.style=Paint.Style.FILL;p.setShadowLayer(18f,0f,0f,Color.rgb(60,190,255));c.drawCircle(cx,cy-h*.05f,5f,p);p.clearShadowLayer();p.color=Color.rgb(150,225,255);p.textAlign=Paint.Align.CENTER;p.textSize=20f;c.drawText("AX",cx,cy+h*.23f,p);p.color=Color.rgb(55,120,170);p.strokeWidth=1f;for(y in 0 until height step 10){val off=(sin((y+phase)*.05)*4).toFloat();c.drawLine(0f,y.toFloat(),w,y.toFloat()+off,p)};phase+=1.2f;postInvalidateDelayed(40)}
}
