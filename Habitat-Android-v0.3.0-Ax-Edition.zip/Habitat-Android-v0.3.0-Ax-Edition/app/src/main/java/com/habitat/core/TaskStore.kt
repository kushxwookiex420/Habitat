package com.habitat.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class TaskStore(context: Context) {
    private val prefs = context.getSharedPreferences("habitat_tasks", Context.MODE_PRIVATE)
    fun all(): MutableList<HabitatTask> {
        val raw = prefs.getString("tasks", "[]") ?: "[]"
        val a = JSONArray(raw); val out = mutableListOf<HabitatTask>()
        for (i in 0 until a.length()) { val o=a.getJSONObject(i); out += HabitatTask(o.getLong("id"),o.getString("title"),o.getString("status"),o.getString("worker"),o.optString("result")) }
        return out
    }
    fun upsert(task: HabitatTask) { val list=all(); val idx=list.indexOfFirst{it.id==task.id}; if(idx>=0) list[idx]=task else list.add(0,task); save(list) }
    fun create(title:String, worker:String): HabitatTask { val t=HabitatTask(System.currentTimeMillis(),title,"QUEUED",worker); upsert(t); return t }
    private fun save(list:List<HabitatTask>) { val a=JSONArray(); list.take(50).forEach{t->a.put(JSONObject().apply{put("id",t.id);put("title",t.title);put("status",t.status);put("worker",t.worker);put("result",t.result)})}; prefs.edit().putString("tasks",a.toString()).apply() }
}
