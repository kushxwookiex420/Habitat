package com.habitat.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class WorkerAdapter(private val context: Context) {
    private val registry=WorkerRegistry(context); private val executor=Executors.newCachedThreadPool()
    data class Result(val ok:Boolean,val text:String,val detail:String="")
    fun run(worker:Worker,prompt:String,callback:(Result)->Unit) {
        executor.execute { val r=try { when(worker.id){"claude"->anthropic(worker,prompt);"gemini"->gemini(worker,prompt);else->compatible(worker,prompt)} } catch(e:Exception){Result(false,"",e.message?:"Worker error")}; callback(r) }
    }
    fun shutdown(){executor.shutdownNow()}
    private fun conn(url:String)= (URL(url).openConnection() as HttpURLConnection).apply{requestMethod="POST";connectTimeout=10000;readTimeout=30000;doOutput=true;setRequestProperty("Content-Type","application/json; charset=UTF-8");setRequestProperty("Accept","application/json")}
    private fun send(c:HttpURLConnection,body:String):Result { OutputStreamWriter(c.outputStream,Charsets.UTF_8).use{it.write(body)}; val code=c.responseCode; val s=if(code in 200..299)c.inputStream else c.errorStream; val raw=s?.let{BufferedReader(InputStreamReader(it,Charsets.UTF_8)).use{r->r.readText()}}?:""; return if(code in 200..299)Result(true,extract(raw)) else Result(false,"","HTTP $code: $raw") }
    private fun compatible(w:Worker,p:String):Result { if(w.endpoint.isBlank())return Result(false,"","No endpoint configured for ${w.name}"); val c=conn(w.endpoint); val key=registry.key(w.id); if(key.isNotBlank())c.setRequestProperty("Authorization","Bearer $key"); c.setRequestProperty("X-Habitat-Client","Ax"); val body=JSONObject().apply{put("model",w.model.ifBlank{"auto"});put("messages",JSONArray().put(JSONObject().put("role","system").put("content","You are a hired worker reporting to Ax/Habitat. Do the assigned job and return concise, useful findings.")).put(JSONObject().put("role","user").put("content",p))}}.toString(); return try{send(c,body)}finally{c.disconnect()} }
    private fun anthropic(w:Worker,p:String):Result { if(w.endpoint.isBlank())return Result(false,"","Claude endpoint is not configured"); val c=conn(w.endpoint); val key=registry.key("claude"); if(key.isBlank())return Result(false,"","Claude API key is not configured"); c.setRequestProperty("x-api-key",key);c.setRequestProperty("anthropic-version","2023-06-01"); val body=JSONObject().apply{put("model",w.model);put("max_tokens",2048);put("system","You are a hired worker reporting to Ax/Habitat.");put("messages",JSONArray().put(JSONObject().put("role","user").put("content",p))) }.toString(); return try{send(c,body)}finally{c.disconnect()} }
    private fun gemini(w:Worker,p:String):Result { if(w.endpoint.isBlank())return Result(false,"","Gemini endpoint is not configured"); val key=registry.key("gemini"); if(key.isBlank())return Result(false,"","Gemini API key is not configured"); val url=if(w.endpoint.contains("?"))"${w.endpoint}&key=$key" else "${w.endpoint.trimEnd('/')}/models/${w.model}:generateContent?key=$key"; val c=conn(url); val body=JSONObject().put("contents",JSONArray().put(JSONObject().put("role","user").put("parts",JSONArray().put(JSONObject().put("text",p))))).toString(); return try{send(c,body)}finally{c.disconnect()} }
    private fun extract(raw:String):String { if(raw.isBlank())return ""; return try{ val o=JSONObject(raw); listOf("response","reply","message","text","content").firstNotNullOfOrNull{if(o.has(it))o.optString(it) else null} ?: o.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: o.optJSONArray("content")?.optJSONObject(0)?.optString("text") ?: raw }catch(_:Exception){raw} }
}
