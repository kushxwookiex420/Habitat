package com.habitat.core
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
class HabitatWidget:AppWidgetProvider(){override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){val p=c.getSharedPreferences("habitat",0);val v=RemoteViews(c.packageName,R.layout.widget_habitat);v.setTextViewText(R.id.widget_title,"HABITAT • AX");v.setTextViewText(R.id.widget_status,"● AX ONLINE • WORKER MANAGER READY");v.setTextViewText(R.id.widget_scene,"Scene: ${p.getString("scene","DESK")}");v.setTextViewText(R.id.widget_message,"Tap to open command center");val i=Intent(c,MainActivity::class.java);val pi=PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(R.id.widget_root,pi);m.updateAppWidget(ids,v)}companion object{fun refresh(c:Context){val m=AppWidgetManager.getInstance(c);val ids=m.getAppWidgetIds(ComponentName(c,HabitatWidget::class.java));c.sendBroadcast(Intent(c,HabitatWidget::class.java).apply{action=AppWidgetManager.ACTION_APPWIDGET_UPDATE;putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,ids)})}}}
