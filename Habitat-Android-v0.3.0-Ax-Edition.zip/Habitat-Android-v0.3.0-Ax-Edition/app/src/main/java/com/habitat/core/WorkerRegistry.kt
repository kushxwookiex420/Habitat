package com.habitat.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class WorkerRegistry(private val context: Context) {
    private val prefs=context.getSharedPreferences("habitat_workers",Context.MODE_PRIVATE)
    fun workers(): List<Worker> = listOf(
        Worker("muse","Muse","Custom / compatible endpoint",get("muse_endpoint"),get("muse_model"),get("muse_enabled")=="1"),
        Worker("claude","Claude","Anthropic",get("claude_endpoint","https://api.anthropic.com/v1/messages"),get("claude_model","claude-sonnet-4-5"),get("claude_enabled")=="1"),
        Worker("gemini","Gemini","Google",get("gemini_endpoint"),get("gemini_model","gemini-2.5-flash"),get("gemini_enabled")=="1"),
        Worker("openrouter","OpenRouter","OpenAI-compatible",get("openrouter_endpoint","https://openrouter.ai/api/v1/chat/completions"),get("openrouter_model","openai/gpt-4o-mini"),get("openrouter_enabled")=="1"),
        Worker("groq","Groq","OpenAI-compatible",get("groq_endpoint","https://api.groq.com/openai/v1/chat/completions"),get("groq_model","llama-3.3-70b-versatile"),get("groq_enabled")=="1")
    )
    fun set(id:String, endpoint:String, model:String, enabled:Boolean, key:String) { prefs.edit().putString("${id}_endpoint",endpoint).putString("${id}_model",model).putString("${id}_enabled",if(enabled)"1" else "0").putString("${id}_key",key).apply() }
    fun key(id:String)=get("${id}_key")
    private fun get(k:String, d:String="")=prefs.getString(k,d)?:d
}
