# Habitat Android v0.2.1 — Ax Edition

This is the next practical Habitat shell: a full-page Android companion UI with a real scene selector, local project/task state, explicit Brain Adapter status, 2D Ax artwork, and a working Android home-screen widget.

## Included now
- Habitat Home / command center
- Ax portrait artwork
- Desk scene artwork
- Chat with locally persisted last message
- Projects dashboard
- Brain status / adapter boundary
- Scene selector: Desk, Chat, Planning, Relax, Night City
- Local SharedPreferences state
- Android home-screen widget that opens Habitat and reflects saved scene/message state
- GitHub Actions debug build

## Intentionally not faked
The Brain Adapter is shown as disconnected until a real intelligence service is wired in. Notifications, voice/lip-sync, autonomous actions, cross-app automation, and a fully animated character are integration layers for later builds.

## Build
Run the GitHub Actions workflow named `Habitat Android Build`. The workflow builds `app-debug.apk` and uploads it as `Habitat-v0.2.1-Ax-debug-apk`.
