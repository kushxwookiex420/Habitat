plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.habitat.core"; compileSdk = 35
    defaultConfig { applicationId = "com.habitat.core"; minSdk = 26; targetSdk = 35; versionCode = 4; versionName = "0.2.2" }
}

kotlin { jvmToolchain(17) }
