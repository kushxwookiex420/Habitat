package com.habitat.core

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class HabitatWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("habitat", Context.MODE_PRIVATE)
        val scene = prefs.getString("scene", "Desk") ?: "Desk"
        val message = prefs.getString("last_message", "")?.takeIf { it.isNotBlank() } ?: "Ax is ready."
        val views = RemoteViews(context.packageName, R.layout.widget_habitat)
        views.setTextViewText(R.id.widget_title, "HABITAT • AX")
        views.setTextViewText(R.id.widget_status, "● Brain adapter: not connected")
        views.setTextViewText(R.id.widget_scene, "Scene: $scene")
        views.setTextViewText(R.id.widget_message, message)
        val intent = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
        val pending = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.widget_root, pending)
        manager.updateAppWidget(ids, views)
    }

    companion object {
        fun refresh(context: Context) {
            val intent = Intent(context, HabitatWidget::class.java).apply { action = AppWidgetManager.ACTION_APPWIDGET_UPDATE }
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, HabitatWidget::class.java))
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            context.sendBroadcast(intent)
        }
    }
}
